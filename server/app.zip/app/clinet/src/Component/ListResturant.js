import React, { Fragment, useState, useEffect } from "react";

import EditRestraunt from "./EditResturant";

const ListResturant = () => {

    const [restraunts, setRestraunts] = useState([]);

    const getRestraunts = async () => {
        try {
            const response = await fetch("http://localhost:5000/resturants");
            const jsonData = await response.json()

            console.log(jsonData)

            setRestraunts(jsonData);
        } catch (err) {
            console.log(err.message)
        }
    }

    // delete function

    const deleteRestruant = async (id) => {
        console.log("I made it here")
        try {
            const deletedResturant = await fetch("http://localhost:5000/resturants/" + id, {
                method: "DELETE"
            });

            console.log(deletedResturant);
            setRestraunts(restraunts.filter(restraunt => restraunt.r_id !== id));

        } catch (err) {
            console.log(err.message)
        }
    }

    useEffect(() => {
        getRestraunts();
    }, []);

    return (
        <Fragment>
            {" "}
            <table class="table mt-5 text-center">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {/*
                     <tr>
                        <td>John</td>
                        <td>Doe</td>
                        <td>john@example.com</td>
                    </tr>
                     */}
                    {restraunts.map(restraunt => (
                        <tr key={restraunt.r_id}>
                            <td>{restraunt.description}</td>
                            <td><EditRestraunt restaurant={restraunt} /></td>
                            <td><button className="btn btn-danger" onClick={() => deleteRestruant(restraunt.r_id)}>
                                Delete
                            </button></td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </Fragment>
    );
};

export default ListResturant;