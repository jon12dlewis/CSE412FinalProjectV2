import './App.css';
import React, { Fragment } from "react";

// components

import InputResturant from "./Component/InputResturant"
import ListResturant from "./Component/ListResturant"


function App() {
  return (
      <Fragment>
          <div className="container">
              <InputResturant />
              <ListResturant/>
          </div>

      </Fragment>
  );
}

export default App;
