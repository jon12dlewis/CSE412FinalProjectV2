import React, { useState } from "react";
import classes from "./RestaurantList.module.css";
import Card from "./RestaurantCard";
import { useEffect } from "react";
import { Grid } from "@mui/material";
import { useNavigate, useParams } from "react-router-dom";


//container for the restaurants
function RestaurantList(props) {
  const [restaurants, setRestaurants] = useState([]);
  const name = props.name;
  const navigate = useNavigate();


  const getRestaurants = async () => {
    try {
      const response = await fetch("http://localhost:5000/restuarants");
      const jsonData = await response.json();

      setRestaurants(jsonData);
    } catch (err) {
      console.log(err.message);
    }
  };

  useEffect(() => {
    getRestaurants();
  }, []);

  return (
    <div className={classes.container}>
      <Grid container spacing={3}>
        {restaurants.map((restaurant) => (
          <Grid key={restaurant.r_id} item xs={3}>
            <Card
              navigate = {()=> navigate(`/ManageRestaurant/${restaurant.r_id}`)}

              title={restaurant.r_name}
              key={restaurant.r_id}
              id={restaurant.r_id}
              img={restaurant.r_image}
              phone={restaurant.r_phone}
              address={restaurant.r_address}
              description={restaurant.r_description}
              rating={restaurant.r_rating}
            />
          </Grid>
        ))}
      </Grid>
    </div>
  );
}

export default RestaurantList;
