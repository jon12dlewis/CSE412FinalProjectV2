import classes from "./ViewReservation.module.css";
import ReservationList from "./ReservationList";
import { useRef, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import ReservationCard from "./ReservationCard";
import { useState } from "react";

export default function ViewReservation() {
  const { id } = useParams();

  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const [reservation, setReservation] = useState();

  const getReservation = async () => {
    try {
      const response = await fetch(
        `http://localhost:5000/reservation/restaurant/${id}`
      );
      const jsonData = await response.json();
      console.log(jsonData);
      setReservation(jsonData);
      setOpen(true);
    } catch (err) {
      console.log(err.message);
    }
  };

  useEffect(() => {
    getReservation();
  }, []);

  function submitHandler() {}
  return (
    <div className={classes.mainContainer}>
      <h1>Reservation</h1>

      

      {open && (
        <div className={classes.container}>
          {reservation.map((item) => (
            <ReservationCard
              key={item.res_id}
              img={item.r_image}
              restaurant={item.r_name}
              date={item.res_date}
              size={item.res_size}
              table={item.t_id}
              name={item.c_name}
            />
          ))}
        </div>
      )}
    </div>
  );
}
