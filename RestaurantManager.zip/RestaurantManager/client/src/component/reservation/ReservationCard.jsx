import React from "react";
import classes from "./ReservationCard.module.css";

//takes in Image, Name,
function ReservationCard(props) {
  return (
    <div className={classes.card}>
      <img src={props.img} alt="" className={classes.image} />
      <div className={classes.container}>
        <h2 className={classes.title}>{props.restaurant}</h2>
        <div>
            <p className={classes.description}>By: {props.name}</p>
            <p className={classes.description}>Table: {props.table}</p>
            <p className={classes.description}>Date : {props.date}</p>
            <p className={classes.description}>Reservation Size: {props.size}</p>
        </div>
    

      </div>
    </div>
  );
}

export default ReservationCard;
