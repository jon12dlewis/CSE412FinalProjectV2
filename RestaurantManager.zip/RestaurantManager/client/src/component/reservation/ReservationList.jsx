import React, { useState } from "react";
import classes from "./ReservationList.module.css";
import ReservationCard from "./ReservationCard";
import { useEffect } from "react";

//container for the restaurants
function ReservationList(props) {
  const [reservation, setReservation] = useState([]);
  const id = props.id;

  const getReservation = async () => {
    try {
      const response = await fetch(
        "http://localhost:5000/reservation/" + props.id
      );
      const jsonData = await response.json();
      setReservation(jsonData);
    } catch (err) {
      console.log(err.message);
    }
  };

  useEffect(() => {
    getReservation();
  }, []);

  return (
    <div className={classes.container}>
      {reservation.map((item) => (
        <ReservationCard
          key={item.res_id}
          img={item.r_image}
          restaurant={item.r_name}
          date={item.res_date}
          size={item.res_size}
          table={item.t_id}
        />
      ))}
    </div>
  );
}

export default ReservationList;
