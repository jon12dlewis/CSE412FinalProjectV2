import { useState, useEffect } from "react";
import { useRef } from "react";
import { useNavigate, useLocation, Link, useParams } from "react-router-dom";
import classes from "./CreateReservation.module.css";
import { Grid } from "@mui/material";

export default function CreateReservation() {
  const { id } = useParams();

  const navigate = useNavigate();

  const [table, setTable] = useState();

  const [name, setName] = useState();
  const [age, setAge] = useState();
  const [address, setAddress] = useState();
  const [phone, setPhone] = useState();
  const [email, setEmail] = useState();
  const [rname, setRname] = useState();
  const [tableID, setTableID] = useState();
  const [tableSize, setTableSize] = useState();

  const [reservationId, setReservationId] = useState(
    Math.floor(Math.random() * 500000)
  );
  const [customerId, setCustomerID] = useState(
    Math.floor(Math.random() * 500000)
  );

  const [show, setShow] = useState(false);
  const [lock, setLock] = useState(false);

  const [toggleTable, setToggleTable] = useState(false);

  const confirm = async () => {
    try {
      let data = {
        c_id: customerId,
        rev_id: null,
        res_id: reservationId,
        c_name: name,
        c_age: age,
        c_address: address,
        c_email: email,
        c_phone: phone,
      };
      const response = await fetch("http://localhost:5000/customer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      console.log(response);
      navigate(-1);
    } catch (err) {
      console.error(err.message);
    }

    //Creata Reservation
    try {
        let data = {
          res_id: reservationId,
          t_id: tableID,
          res_date: null,
          res_size: tableSize,
        };
        const response = await fetch("http://localhost:5000/reservation", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });
        console.log(response);
      } catch (err) {
        console.error(err.message);
      }
  };


  const getReservation = async () => {
    try {
      const response = await fetch("http://localhost:5000/dineTable/" + id);
      const jsonData = await response.json();
      setTable(jsonData);
    } catch (err) {
      console.log(err.message);
    }
  };

  useEffect(() => {
    getReservation();
  }, []);

  return (
    <>
      <h1>Create Reservation</h1>
      {!show && !lock && (
        <div className={classes.container}>
          <form className={classes.form}>
            <div className={classes.control}>
              <label htmlFor="name">Name</label>
              <input
                type="text"
                required
                id="name"
                onChange={(e) => {
                  setName(e.currentTarget.value);
                }}
              />
            </div>
            <div className={classes.control}>
              <label htmlFor="age">Age</label>
              <input
                type="number"
                required
                id="age"
                onChange={(e) => {
                  setAge(e.currentTarget.value);
                }}
              />
            </div>
            <div className={classes.control}>
              <label htmlFor="address">Address</label>
              <input
                type="text"
                required
                id="address"
                onChange={(e) => {
                  setAddress(e.currentTarget.value);
                }}
              />
            </div>
            <div className={classes.control}>
              <label htmlFor="email">Email</label>
              <input
                type="text"
                required
                id="email"
                onChange={(e) => {
                  setEmail(e.currentTarget.value);
                }}
              />
            </div>
            <div className={classes.control}>
              <label htmlFor="phone">Phone Number</label>
              <input
                type="text"
                required
                id="phone"
                onChange={(e) => {
                  setPhone(e.currentTarget.value);
                }}
              />
            </div>
            <div className={classes.actions}>
              <button type="submit" onClick={() => setLock(!lock)}>
                Continue
              </button>
            </div>
          </form>
        </div>
      )}

      {!show && lock && (
        <div className={classes.container}>
          <form className={classes.form}>
            <div className={classes.control}>
              <label>Pick A Seat</label>
            </div>

            <div className={classes.tables}>
              <Grid className={classes.grid} container spacing={2}>
                {table
                  .filter((e) => e.reserved)
                  .map((table) => (
                    <Grid key={table.t_id} item xs={4}>
                      <div
                        className={classes.card}
                        onClick={() => {
                          setShow(true);
                          setRname(table.r_name);
                          setTableID(table.t_id);
                          setTableSize(table.res_size);
                        }}
                      >
                        <div className={classes.textContainer}>
                          <h2 className={classes.cardText}>
                            Capacity: {table.max_seats}
                          </h2>
                          <h2 className={classes.cardText}>ID: {table.t_id}</h2>
                        </div>
                      </div>
                    </Grid>
                  ))}
              </Grid>
            </div>

            <div className={classes.buttonContainer}>
              <div className={classes.actions}>
                <button type="button" onClick={() => setLock(!lock)}>
                  Back
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {show && (
        <div className={classes.container}>
          <form className={classes.form}>
            <div className={classes.control}>
              <label>Your Reservation Code: {reservationId}</label>
            </div>
            <div className={classes.outputContainer}>
              <p>Name: {name}</p>
              <p>Address: {address} </p>
              <p>Phone: {phone}</p>
              <p>Email: {email} </p>
              <p>Reservation For: {rname}</p>
              <p>Table ID: {tableID} </p>
            </div>

            <div className={classes.tables}></div>
            <div className={classes.buttonContainer}>
              <div className={classes.actions}>
                <button
                  type="button"
                  onClick={() => {
                    setShow(!show);
                  }}
                >
                  Back
                </button>
              </div>
              <div className={classes.actions}>
                <button type="button" onClick={confirm}>
                  Confirm
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </>
  );
}
