import React from "react";
import { Container, Navbar as NavBarBs, Nav } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import classes from "./NavBar.module.css";

function NavBar() {
  return (
    <NavBarBs className = {classes.nav}>
      <Container className={classes.container}>
        <Nav>
          <Nav.Link to={"/"} as={NavLink} className={classes.home}>
            Home
          </Nav.Link>
          <Nav.Link to={"/AddRestaurant"} as={NavLink} className={classes.addRes}>
            Create Restaurants
          </Nav.Link>
          <Nav.Link to={"/Reservation"} as={NavLink} className={classes.addRes}>
            View Reservation
          </Nav.Link>
        </Nav>
      </Container>
    </NavBarBs>
  );
}

export default NavBar;
