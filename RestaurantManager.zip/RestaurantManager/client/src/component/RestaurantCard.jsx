import React from "react";
import classes from "./RestaurantCard.module.css";

//takes in Image, Name,
function RestaurantCard(props) {
  

  return (
    <div className={classes.card} onClick={props.navigate}>
      <img src={props.img} alt="" className={classes.image} />
      <div className={classes.container}>
        <h2 className={classes.title}>{props.title}</h2>
        <p className={classes.description}>{props.description}</p>

        <div className={classes.info}>
          <p className={classes.address}>{props.address}</p>
          <p className={classes.phone}>{props.phone}</p>
        </div>

        <div className={classes.id_container}>
          <p className={classes.id}>{props.id}</p>
        </div>
      </div>
    </div>
    
  );
}

export default RestaurantCard;
