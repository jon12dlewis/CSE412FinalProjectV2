import classes from "./ReservationPage.module.css";
import ReservationList from "../component/reservation/ReservationList";
import { useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useEffect } from "react";

export default function ReservationPage() {
    const [id, setId] = useState(0);
    const [open, setOpen] = useState(false)

  function submitHandler() {
    setOpen(true)
  }
  return (
    <div className={classes.mainContainer}>
      <h1>Reservation</h1>

      <div className={classes.container}>
        <form className={classes.form} onSubmit={submitHandler}>
          <div className={classes.control}>
            <label htmlFor="id">Reservation ID</label>
            <input type="number" required id="id" onChange={e => setId(e.target.value)}/>
          </div>
          <div className={classes.actions}>
            <button type="button" onClick={submitHandler}>
              Search
            </button>
          </div>
        </form>
      </div>
      {open && <ReservationList id={id}/>}
    </div>
  );
}
