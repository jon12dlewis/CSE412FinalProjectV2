import { useState } from "react";
import { useRef } from "react";
import { useNavigate, useParams} from "react-router-dom";

import classes from "./CreateReview.module.css";
export default function CreateReview(props) {
  const { id } = useParams();

  const navigate = useNavigate();
  const [name, setName] = useState();
  const [address, setAddress] = useState();
  const [text,setText] = useState();
  const [rating,setRating] = useState();
  const [date,setDate] = useState();


  const submitHandler = async () => {
    try {
      const rev_id = Math.floor(Math.random() * 100000);
      console.log(rev_id, id, text, date )
      let data = {
        rev_id: rev_id,
        r_id: id,
        rev_text: text,
        rev_date: date,
        rev_rating: rating,
        name: name
      };      
 
      

      const response = await fetch("http://localhost:5000/review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      console.log(response)
     navigate(-1);

    } catch (err) {
      console.error(err.message);
    }
  };

  return (
    <>
      <h1>Review</h1>
      <div className={classes.container}>
        <form className={classes.form} >
          <div className={classes.control}>
            <label htmlFor="name">Name</label>
            <input type="text" required id="name" onChange={(e) => setName(e.currentTarget.value)} />
          </div>
          <div className={classes.control}>
            <label htmlFor="review">Review</label>
            <textarea
              id="review"
              required
              rows="5"
              onChange={(e) => setText(e.currentTarget.value)}
              
            ></textarea>
          </div>
          <div className={classes.control}>
            <label htmlFor="address">Date</label>
            <input type="text" required id="address" onChange={(e) => setDate(e.currentTarget.value)}/>
          </div>
          <div className={classes.control}>
            <label htmlFor="rating">Rating Out of 5</label>
            <input type="text" required id="rating" onChange={(e) => setRating(e.currentTarget.value)} />
          </div>

          <div className={classes.actions}>
            <button type="button" onClick={submitHandler}>Submit</button>
          </div>
        </form>
      </div>
    </>
  );
}
