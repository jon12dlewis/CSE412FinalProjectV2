import { useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";


import classes from "./DeleteRestaurant.module.css";

export default function DeleteRestaurant() {
  const navigate = useNavigate();
  const [id, setId] = useState(0);

  const submitHandler = async () => {
    try {
      
      const response = await fetch("http://localhost:5000/restuarants/"+ id, {
        method: "DELETE",
      });
      console.log(response);
    //   navigate(-1);
    } catch (err) {
      console.error(err.message);
    }
  };

  return (
    <div className={classes.mainContainer}>
      <h1>Delete</h1>

      <div className={classes.container}>
        <form className={classes.form}>
          <div className={classes.control}>
            <label htmlFor="name">Restaurant Id</label>
            <input type="number" required id="name" onChange={e => setId(e.target.value)}/>
          </div>
          <div className={classes.actions}>
            <button type="button" onClick={submitHandler}>
              Delete
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
