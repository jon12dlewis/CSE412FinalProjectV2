import { useState } from "react";
import { useRef } from "react";
import { useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";

import classes from "./EditRestaurant.module.css";
export default function EditRestaurant() {
  const [restaurants, setRestaurants] = useState();
  const [load, setLoad] = useState(false);
  const { id } = useParams();

  const [name, setName] = useState();
  const [address, setAddress] = useState();
  const [description, setDescription] = useState();
  const [phone, setPhone] = useState();
  const [image, setImage] = useState();

  const navigate = useNavigate();

  const submitHandler = async () => {
    try {
      let data = {
        r_name: name,
        r_address: address,
        r_description: description,
        r_phone: phone,
        r_image: image,
        r_id: id
      };

      const response = await fetch(`http://localhost:5000/restuarants/update`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      console.log(response);
      navigate(-1);
    } catch (err) {
      console.error(err.message);
    }
  };

  const getRestaurants = async () => {
    try {
      const response = await fetch(`http://localhost:5000/restuarants/${id}`);
      const jsonData = await response.json();

      setRestaurants(jsonData[0]);
      setLoad(true);
      setName(jsonData[0].r_name);
      setAddress(jsonData[0].r_address);
      setDescription(jsonData[0].r_description);
      setPhone(jsonData[0].r_phone);
      setImage(jsonData[0].r_image);

    } catch (err) {
      console.log(err.message);
    }
  };

  useEffect(() => {
    getRestaurants();
  }, []);

  return (
    <>
      <h1>Edit Restaurant</h1>
        <div className={classes.container}>
          <form className={classes.form}>
            <div className={classes.control}>
              <label htmlFor="name">Restaurant Name</label>
              <input
                type="text"
                required
                defaultValue={name}
                id="name"
                onChange={(e) => {setName(e.currentTarget.value)}}
              />
            </div>
            <div className={classes.control}>
              <label htmlFor="description">Description</label>
              <textarea
                defaultValue={description}
                onChange={(e) => setDescription(e.currentTarget.value)}
                id="description"
                required
                rows="5"
              ></textarea>
            </div>
            <div className={classes.control}>
              <label htmlFor="address">Address</label>
              <input
                type="text"
                required
                defaultValue={address}
                id="address"
                onChange={(e) => setAddress(e.currentTarget.value)}
              />
            </div>
            <div className={classes.control}>
              <label htmlFor="phone">Phone Number</label>
              <input
                type="text"
                required
                id="phone"
                defaultValue={phone}
                onChange={(e) => setPhone(e.currentTarget.value)}
              />
            </div>
            <div className={classes.control}>
              <label htmlFor="image">Image URL</label>
              <input
                type="text"
                required
                id="image"
                defaultValue={image}
                onChange={(e) => setImage(e.currentTarget.value)}
              />
            </div>
            <div className={classes.actions}>
              <button type="button" onClick={submitHandler}>
                Edit Restaurant
              </button>
            </div>
          </form>
        </div>
      
    </>
  );
}
