import { useRef } from "react";
import { useNavigate } from "react-router-dom";

import classes from "./AddRestaurant.module.css";
export default function ManageRestaurant() {
  const navigate = useNavigate();
  const name = useRef();
  const address = useRef();
  const description = useRef();
  const phone = useRef();
  const image = useRef();


  const submitHandler = async () => {
    try {
      const id = Math.floor(Math.random() * 100000);
      let data = {
        r_id: id,
        r_name: name.current.value,
        r_address: address.current.value,
        r_description: description.current.value,
        r_phone: phone.current.value,
        r_rating: null,
        r_image: image.current.value,
      };      
      const response = await fetch("http://localhost:5000/restuarants", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      console.log(response)
     navigate(-1);

    } catch (err) {
      console.error(err.message);
    }
  };

  return (
    <>
      <h1>Add New Restaurant</h1>
      <div className={classes.container}>
        <form className={classes.form} >
          <div className={classes.control}>
            <label htmlFor="name">Restaurant Name</label>
            <input type="text" required id="name" ref={name} />
          </div>
          <div className={classes.control}>
            <label htmlFor="description">Description</label>
            <textarea
              id="description"
              required
              rows="5"
              ref={description}
            ></textarea>
          </div>
          <div className={classes.control}>
            <label htmlFor="address">Address</label>
            <input type="text" required id="address" ref={address} />
          </div>
          <div className={classes.control}>
            <label htmlFor="phone">Phone Number</label>
            <input type="text" required id="phone" ref={phone} />
          </div>
          <div className={classes.control}>
            <label htmlFor="image">Image URL</label>
            <input type="text" required id="image" ref={image} />
          </div>
          <div className={classes.actions}>
            <button type="button" onClick={submitHandler}>Create Restaurant</button>
          </div>
        </form>
      </div>
    </>
  );
}
