import { useRef, useState, useEffect } from "react";
import { useNavigate, useLocation, Link, useParams } from "react-router-dom";
import Card from "../../component/RestaurantCard";

import { Grid } from "@mui/material";

import classes from "./ManageRestaurant.module.css";
export default function ManageRestaurant(props) {
  const navigate = useNavigate();
  const { id } = useParams();

  const [data, setData] = useState();
  const [review, setReview] = useState();
  const [lock, setLock] = useState(false);
  const [seatCapacity, setSeactCapacity] = useState();
  

  const [show, setShow] = useState(false);

  const getRestaurants = async () => {
    try {
      const response = await fetch(`http://localhost:5000/restuarants/${id}`);
      const jsonData = await response.json();

      setData(jsonData);
    } catch (err) {
      console.log(err.message);
    }

    try {
      const response = await fetch(`http://localhost:5000/reviews/${id}`);
      const jsonData = await response.json();

      setReview(jsonData);
      setLock(true);
    } catch (err) {
      console.log(err.message);
    }
    setLock(true);
  };

  const addSeat = async() =>{
    const tableID = Math.floor(Math.random() * 100000);
    try {
      let data = {
        t_id: tableID,
        r_id: id,
        max_seats: seatCapacity,
        reserved: false,
      };
      const response = await fetch("http://localhost:5000/dine_table", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      console.log(response);

    }catch(err){
      console.error(err.message)
    }

  }


  useEffect(() => {
    getRestaurants();
  }, []);

  useEffect(()=>{
    addSeat();
  },[seatCapacity])

  

  const deleteHandler = async () => {
    try {
      const response = await fetch("http://localhost:5000/restuarants/" + id, {
        method: "DELETE",
      });
      navigate(-1);
    } catch (err) {
      console.error(err.message);
    }
  };



  return (
    <>
      <>
      <h1>Manage Restaurant</h1>
      {lock && (
        <div>
          {data.map((restaurant) => (
            <Card
              title={restaurant.r_name}
              key={restaurant.r_id}
              id={restaurant.r_id}
              img={restaurant.r_image}
              phone={restaurant.r_phone}
              address={restaurant.r_address}
              description={restaurant.r_description}
              rating={restaurant.r_rating}
            />
          ))}
        </div>
      )}

      <div></div>
      <div className={classes.container}>
        <div className={classes.actions}>
          <button
            type="button"
            onClick={() => navigate(`/CreateReservation/${id}`)}
          >
            Create Reservation
          </button>
        </div>
        <div className={classes.actions}>
          <button type="button" onClick={deleteHandler}>
            Delete Restaurant
          </button>
        </div>
        <div className={classes.actions}>
          <button
            type="button"
            onClick={() => navigate(`/EditRestaurant/${id}`)}
          >
            Edit Restaurant
          </button>
        </div>
        <div className={classes.actions}>
          <button
            type="button"
            onClick={() => navigate(`/ViewReservation/${id}`)}
          >
            View Reservations
          </button>
        </div>
      </div>
      <div className={classes.actions}>
        <button type="button" onClick={() => navigate(`/CreateReview/${id}`)}>
          Create Review
        </button>
      </div>
      <h1>Reviews</h1>

      {lock && (
        <div className={classes.reviewContainer}>
          {review.map((e) => (
            <div key={e.rev_id} className={classes.card}>
              <img src={props.img} alt="" className={classes.image} />
              <div className={classes.container}>
                <h2 className={classes.title}>{e.name}</h2>
                <div>
                  <p className={classes.description}>{e.rev_date}</p>
                  <p className={classes.description}>
                    Rating: {e.rev_rating}/5
                  </p>
                  <p className={classes.description}> {e.rev_text}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      </>
      
      
      
        
    </>
  );
}
