import RestaurantList from "../component/RestaurantList"
import classes from "./Home.module.css"

export default function Home(){
    return(
        <div className={classes.mainContainer}>
            <h1>Restaurant List</h1>
            <RestaurantList />

        </div>
    )
}
