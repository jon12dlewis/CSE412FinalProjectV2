export default function RestaurantPage(){
    return (<h1>Restaurant Page</h1>)
}
