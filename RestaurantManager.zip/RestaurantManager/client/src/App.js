import {Container} from 'react-bootstrap'
import {Route} from 'react-router-dom'
import {Routes} from 'react-router-dom'
import Home from "./pages/Home";
import Layout from './component/layout/Layout';
import ManageRestaurant from "./pages/restaurant/ManageRestaurant";
import RestaurantPage from "./pages/RestaurantPage";
import ReservationPage from "./pages/ReservationPage"
import AddRestaurant from './pages/restaurant/AddRestaurant';
import DeleteRestaurant from './pages/restaurant/DeleteRestaurant';
import EditRestaurant from './pages/restaurant/EditRestaurant';
import CreateReservation from './component/reservation/CreateReservation';
import CreateReview from './pages/reviews/CreateReview';
import ViewReservation from './component/reservation/ViewReservation';


function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/ManageRestaurant/:id" element={<ManageRestaurant/>}/>
        <Route path="/restaurantPage" element={<RestaurantPage/>}/>
        <Route path="/Reservation" element={<ReservationPage/>}/>
        <Route path="/AddRestaurant" element={<AddRestaurant/>}/>
        <Route path="/DeleteRestaurant" element={<DeleteRestaurant/>}/>
        <Route path="/EditRestaurant/:id" element={<EditRestaurant/>}/>
        <Route path="/CreateReservation/:id" element={<CreateReservation/>}/>
        <Route path="/CreateReview/:id" element={<CreateReview/>}/>
        <Route path="/ViewReservation/:id" element={<ViewReservation/>}/>


      </Routes>
    </Layout>  
    
  );
}

export default App;
